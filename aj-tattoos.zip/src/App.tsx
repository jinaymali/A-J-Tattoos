/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { Instagram, Phone, MapPin, ArrowUpRight } from 'lucide-react';

// --- UTILS & TYPES ---
const fadeIn = (delay = 0, y = 20) => ({
  initial: { opacity: 0, y },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-50px" },
  transition: { duration: 0.8, delay, ease: [0.25, 0.1, 0.25, 1] }
});

// --- COMPONENTS ---

const Magnet = ({ children, padding = 150, strength = 3 }: { children: React.ReactNode, padding?: number, strength?: number }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const { clientX, clientY } = e;
    const { left, top, width, height } = ref.current.getBoundingClientRect();
    const centerX = left + width / 2;
    const centerY = top + height / 2;
    const distanceX = clientX - centerX;
    const distanceY = clientY - centerY;

    if (Math.abs(distanceX) < padding && Math.abs(distanceY) < padding) {
      setPosition({ x: distanceX / strength, y: distanceY / strength });
    } else {
      setPosition({ x: 0, y: 0 });
    }
  };

  const handleMouseLeave = () => setPosition({ x: 0, y: 0 });

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 150, damping: 15, mass: 0.1 }}
    >
      {children}
    </motion.div>
  );
};

const BookingButton = ({ className = "" }: { className?: string }) => (
  <motion.button
    whileHover={{ scale: 1.05 }}
    whileTap={{ scale: 0.95 }}
    className={`relative overflow-hidden group px-8 py-3 sm:px-12 sm:py-4 rounded-full uppercase tracking-[0.2em] font-bold text-white transition-all duration-300 shadow-[inset_0_0_20px_rgba(255,255,255,0.2)] border border-white/20 ${className}`}
    style={{
      background: 'linear-gradient(123deg, #2A0000 7%, #D62828 40%, #7A1010 75%, #FF5C5C 100%)'
    }}
  >
    <span className="relative z-10">Book Session</span>
    <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
  </motion.button>
);

const AnimatedText = ({ text }: { text: string }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.9", "start 0.5"]
  });

  return (
    <p ref={ref} className="flex flex-wrap justify-center">
      {text.split(" ").map((word, i) => (
        <motion.span 
          key={i} 
          style={{ opacity: scrollYProgress }} 
          className="mr-2 mb-1"
        >
          {word}
        </motion.span>
      ))}
    </p>
  );
};

// --- SECTIONS ---

const HeroSection = () => {
  return (
    <section className="relative h-screen w-full flex flex-col overflow-hidden bg-dark">
      {/* Navbar */}
      <motion.nav 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center px-6 md:px-10 pt-6 md:pt-8 z-50"
      >
        <div className="text-xl font-black tracking-tighter text-light">AJ.</div>
        <div className="hidden md:flex gap-10 text-[1rem] lg:text-[1.1rem] uppercase tracking-[0.18em] font-medium text-light">
          {['About', 'Services', 'Artists', 'Gallery', 'Contact'].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} className="hover:opacity-50 transition-opacity">
              {item}
            </a>
          ))}
        </div>
        <BookingButton className="hidden sm:block !px-6 !py-2 text-xs" />
      </motion.nav>

      {/* Main Content */}
      <div className="flex-1 flex flex-col justify-center items-center relative z-20">
        <motion.h1 
          {...fadeIn(0.15, 40)}
          className="hero-heading font-black uppercase leading-none tracking-tighter whitespace-nowrap text-[13vw] sm:text-[14vw] md:text-[15vw] lg:text-[16vw]"
        >
          Ink With Attitude
        </motion.h1>
      </div>

      {/* Floating Centerpiece */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 sm:top-auto sm:bottom-0 sm:translate-y-0 z-10 w-[280px] sm:w-[360px] md:w-[460px] lg:w-[560px]">
        <Magnet strength={5}>
          <motion.img 
            {...fadeIn(0.6, 30)}
            src="https://images.unsplash.com/photo-1542727365-19732a80dcfd?q=80&w=1400&auto=format&fit=crop"
            referrerPolicy="no-referrer"
            alt="Hero Tattoo Art"
            className="w-full h-auto drop-shadow-[0_0_50px_rgba(214,40,40,0.3)]"
          />
        </Magnet>
      </div>

      {/* Bottom Bar */}
      <div className="px-6 md:px-10 pb-8 md:pb-10 flex flex-col sm:flex-row justify-between items-center sm:items-end z-20 gap-6">
        <motion.div {...fadeIn(0.35, 20)} className="max-w-[280px] sm:max-w-[360px]">
          <p className="text-light uppercase tracking-wide font-light leading-snug text-[clamp(0.8rem,1.4vw,1.3rem)]">
            Custom tattoos crafted with precision, personality, and timeless artistry.
          </p>
        </motion.div>
        <motion.div {...fadeIn(0.5, 20)}>
          <BookingButton />
        </motion.div>
      </div>
    </section>
  );
};

const MarqueeGallery = () => {
  const container = useRef(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ["start end", "end start"]
  });

  const x1 = useTransform(scrollYProgress, [0, 1], [0, -500]);
  const x2 = useTransform(scrollYProgress, [0, 1], [-500, 0]);

  const images = [
    "https://images.unsplash.com/photo-1550537687-c91072c4792d?q=80&w=800",
    "https://images.unsplash.com/photo-1590201842831-ca36d405105d?q=80&w=800",
    "https://images.unsplash.com/photo-1611501275019-9b5cda994e8d?q=80&w=800",
    "https://images.unsplash.com/photo-1598371839696-5c5bb00bdc28?q=80&w=800",
    "https://images.unsplash.com/photo-1562967914-608f82629710?q=80&w=800",
  ];

  return (
    <section ref={container} className="bg-dark py-24 sm:py-40 overflow-hidden select-none">
      <motion.div style={{ x: x1 }} className="flex gap-4 mb-4 whitespace-nowrap will-change-transform">
        {[...images, ...images, ...images].map((src, i) => (
          <img key={i} src={src} referrerPolicy="no-referrer" className="w-[300px] md:w-[420px] h-[270px] rounded-2xl object-cover grayscale hover:grayscale-0 transition-all duration-500" alt="Tattoo work" loading="lazy" />
        ))}
      </motion.div>
      <motion.div style={{ x: x2 }} className="flex gap-4 whitespace-nowrap will-change-transform">
        {[...images, ...images, ...images].reverse().map((src, i) => (
          <img key={i} src={src} referrerPolicy="no-referrer" className="w-[300px] md:w-[420px] h-[270px] rounded-2xl object-cover grayscale hover:grayscale-0 transition-all duration-500" alt="Tattoo work" loading="lazy" />
        ))}
      </motion.div>
    </section>
  );
};

const AboutSection = () => {
  return (
    <section id="about" className="min-h-screen bg-dark flex flex-col items-center justify-center px-5 py-20 relative text-center">
      <div className="absolute top-10 left-10 opacity-10 pointer-events-none">
        <img src="https://cdn.pixabay.com/photo/2017/01/31/15/33/skull-2025117_1280.png" referrerPolicy="no-referrer" className="w-64 invert" alt="decor" />
      </div>
      
      <motion.h2 
        {...fadeIn()}
        className="hero-heading uppercase font-black tracking-tight text-[clamp(3rem,12vw,160px)] leading-none mb-10"
      >
        About AJ
      </motion.h2>

      <div className="max-w-[620px] text-light font-medium leading-relaxed text-[clamp(1rem,2vw,1.35rem)] mb-20">
        <AnimatedText text="AJ Tattoos blends modern ink culture with timeless craftsmanship. From bold blackwork to intricate realism, every piece is designed to reflect individuality, emotion, and identity. Our mission is to create unforgettable tattoos that live with you forever." />
      </div>

      <motion.div {...fadeIn(0.4)}>
        <BookingButton />
      </motion.div>
    </section>
  );
};

const ServicesSection = () => {
  const services = [
    { id: '01', title: 'Blackwork Tattoos', desc: 'Bold and high-contrast black ink compositions inspired by modern and traditional tattoo culture.' },
    { id: '02', title: 'Realism Tattoos', desc: 'Highly detailed portrait and realism tattoos crafted with depth, shading, and lifelike precision.' },
    { id: '03', title: 'Japanese Style', desc: 'Large-scale Japanese-inspired body art featuring mythology, flow, and iconic symbolism.' },
    { id: '04', title: 'Fine Line Tattoos', desc: 'Elegant minimal tattoos using ultra-thin precision lines and delicate detailing.' },
    { id: '05', title: 'Custom Tattoo Design', desc: 'Personalized tattoo concepts developed collaboratively to create one-of-a-kind wearable art.' },
  ];

  return (
    <section id="services" className="bg-[#F5F5F5] rounded-t-[40px] sm:rounded-t-[60px] py-20 md:py-32 px-5 md:px-10 text-dark">
      <div className="max-w-6xl mx-auto">
        <motion.h2 
          {...fadeIn()}
          className="uppercase text-center font-black text-[clamp(3rem,10vw,140px)] leading-none mb-20"
        >
          Services
        </motion.h2>

        <div className="flex flex-col">
          {services.map((s, i) => (
            <motion.div 
              key={s.id}
              {...fadeIn(i * 0.1)}
              className="group flex flex-col md:flex-row items-start md:items-center border-t border-dark/15 py-10 md:py-14 gap-6"
            >
              <span className="font-black text-[clamp(2.5rem,8vw,100px)] leading-none min-w-[140px] opacity-20 group-hover:opacity-100 transition-opacity duration-500">
                {s.id}
              </span>
              <div className="flex-1">
                <h3 className="uppercase font-medium text-[clamp(1.2rem,2.5vw,2.1rem)] mb-2">{s.title}</h3>
                <p className="font-light leading-relaxed max-w-2xl opacity-60 text-[clamp(0.9rem,1.6vw,1.2rem)]">{s.desc}</p>
              </div>
              <ArrowUpRight className="hidden md:block opacity-0 group-hover:opacity-100 transition-opacity" size={40} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ArtistCard = ({ name, role, img }: { name: string, role: string, img: string }) => (
  <motion.div 
    whileHover={{ y: -10 }}
    className="bg-[#101010] rounded-[36px] border border-white/10 overflow-hidden transition-all duration-500 group"
  >
    <div className="h-[400px] overflow-hidden">
      <img src={img} alt={name} referrerPolicy="no-referrer" className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700" />
    </div>
    <div className="p-8">
      <h3 className="text-2xl font-bold text-light mb-1">{name}</h3>
      <p className="text-light/50 uppercase tracking-widest text-sm mb-6">{role}</p>
      <div className="flex gap-4">
        <Instagram size={20} className="text-light hover:text-accent-red cursor-pointer transition-colors" />
      </div>
    </div>
  </motion.div>
);

const ArtistsSection = () => {
  const artists = [
    { name: "AJ", role: "Blackwork Specialist", img: "https://images.unsplash.com/photo-1590548366474-061034f8286a?q=80&w=800" },
    { name: "Rhea", role: "Fine Line Artist", img: "https://images.unsplash.com/photo-1597484662317-9bd7732dfad6?q=80&w=800" },
    { name: "Zane", role: "Japanese & Neo-Traditional", img: "https://images.unsplash.com/photo-1581333100576-b73bbe79c210?q=80&w=800" },
  ];

  return (
    <section id="artists" className="bg-dark py-32 px-5 md:px-10">
      <div className="max-w-7xl mx-auto">
        <motion.h2 {...fadeIn()} className="hero-heading uppercase font-black text-[clamp(3rem,10vw,140px)] text-center mb-20">Artists</motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {artists.map((a, i) => <ArtistCard key={i} {...a} />)}
        </div>
      </div>
    </section>
  );
};

const StackingCard = ({ index, total, title, category, num }: any) => {
  const container = useRef(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ["start end", "start start"]
  });

  const scale = useTransform(scrollYProgress, [0, 1], [1 + (total - index) * 0.05, 1 - (total - index) * 0.03]);

  return (
    <motion.div 
      ref={container}
      style={{ scale }}
      className="sticky top-24 md:top-32 h-[75vh] md:h-[85vh] w-full bg-dark border-2 border-light rounded-[40px] md:rounded-[60px] p-6 md:p-10 mb-10 overflow-hidden flex flex-col"
    >
      <div className="flex justify-between items-start mb-10">
        <div>
          <span className="block text-5xl font-black mb-4">{num}</span>
          <span className="text-accent-gold uppercase tracking-widest text-sm">{category}</span>
          <h3 className="text-4xl md:text-6xl font-black uppercase text-light">{title}</h3>
        </div>
        <button className="rounded-full border-2 border-light px-6 py-2 uppercase tracking-widest text-xs hover:bg-light hover:text-dark transition-all cursor-pointer">
          View Gallery
        </button>
      </div>
      <div className="flex-1 grid grid-cols-2 gap-4">
        <img src={`https://images.unsplash.com/photo-1560707303-4e980ce876ad?q=80&w=800&sig=${index}`} referrerPolicy="no-referrer" className="w-full h-full object-cover rounded-3xl" alt="Gallery" />
        <img src={`https://images.unsplash.com/photo-1598371839696-5c5bb00bdc28?q=80&w=800&sig=${index+10}`} referrerPolicy="no-referrer" className="w-full h-full object-cover rounded-3xl" alt="Gallery" />
      </div>
    </motion.div>
  );
};

const ProjectsSection = () => {
  const collections = [
    { num: '01', title: 'Black Ritual', category: 'Blackwork' },
    { num: '02', title: 'Tokyo Ghost', category: 'Japanese' },
    { num: '03', title: 'Sacred Geometry', category: 'Geometric' },
  ];

  return (
    <section id="gallery" className="bg-dark px-5 md:px-10 py-20">
      <div className="max-w-6xl mx-auto">
        <motion.h2 {...fadeIn()} className="hero-heading uppercase font-black text-center text-[clamp(3rem,10vw,140px)] mb-20">Gallery</motion.h2>
        <div className="relative">
          {collections.map((c, i) => (
            <StackingCard key={i} index={i} total={collections.length} {...c} />
          ))}
        </div>
      </div>
    </section>
  );
};

const ContactSection = () => {
  return (
    <section id="contact" className="bg-dark py-32 px-5 text-center flex flex-col items-center">
      <motion.h2 {...fadeIn()} className="hero-heading uppercase font-black text-[clamp(2.5rem,8vw,120px)] leading-none mb-6">
        Ready To Get Inked?
      </motion.h2>
      <motion.p {...fadeIn(0.1)} className="text-light/70 max-w-xl text-lg mb-12">
        Book your consultation and turn your vision into timeless art.
      </motion.p>
      
      <motion.div {...fadeIn(0.2)} className="mb-20">
        <BookingButton />
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-light max-w-4xl w-full pt-20 border-t border-white/10">
        <div className="flex flex-col items-center gap-4">
          <Instagram size={32} className="text-accent-red" />
          <p className="uppercase tracking-widest font-bold">@ajtattoos_studio</p>
        </div>
        <div className="flex flex-col items-center gap-4">
          <Phone size={32} className="text-accent-red" />
          <p className="uppercase tracking-widest font-bold">+1 (555) 000-INKY</p>
        </div>
        <div className="flex flex-col items-center gap-4">
          <MapPin size={32} className="text-accent-red" />
          <p className="uppercase tracking-widest font-bold text-sm">Downtown Arts District, NY</p>
        </div>
      </div>
    </section>
  );
};

// --- MAIN PAGE ---

export default function App() {
  return (
    <main className="bg-dark text-light font-sans overflow-x-clip selection:bg-accent-red selection:text-white">
      <HeroSection />
      <MarqueeGallery />
      <AboutSection />
      <ServicesSection />
      <ArtistsSection />
      <ProjectsSection />
      <ContactSection />

      <footer className="py-10 text-center text-xs tracking-widest opacity-30 uppercase border-t border-white/5">
        © {new Date().getFullYear()} AJ Tattoos Studio — Ink Beyond Art
      </footer>
    </main>
  );
}

